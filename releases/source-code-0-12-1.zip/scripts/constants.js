/*
*   constants.js
*/

export const dataAttribName = 'data-ilps';
export const debug = false;
